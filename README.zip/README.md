# News Paper Theme

News Paper Theme with dark mode